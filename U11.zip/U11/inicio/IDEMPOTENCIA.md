# Reto U11: clave de idempotencia para crear alumnos

## Diseño

**Cabecera.** `POST /api/v1/alumnos` acepta `Idempotency-Key` (opcional, 1 a 80 caracteres `[A-Za-z0-9._-]`).
Sin la cabecera, el comportamiento no cambia.

**Tabla.** `idempotencia_alumnos(principal, clave, huella, alumno_id, creada)`, migración `V3`.

**Restricción única.** `PRIMARY KEY (principal, clave)`. La clave pertenece al solicitante autenticado:
dos usuarios pueden usar el mismo texto sin colisionar. `alumno_id` referencia a `alumnos` con
`ON DELETE CASCADE`: si se elimina el alumno, la clave deja de reproducirlo.

**Huella.** SHA-256 del contenido canónico (matrícula en mayúsculas, nombre y correo sin espacios en los
extremos). Cada campo lleva su longitud para que `("AB","C")` y `("A","BC")` no coincidan.

**Transacción.** Todo ocurre en una sola transacción:
1. `INSERT ... ON CONFLICT DO NOTHING` reserva la clave. Si otra transacción la reservó sin confirmar,
   PostgreSQL espera su commit o rollback antes de decidir.
2. Si la reserva fue nuestra, se crea el alumno y se asigna `alumno_id`. Alumno y clave se confirman juntos.
3. Si hubo conflicto, se lee la fila ya confirmada y se compara la huella.

**Respuesta de una repetición.**
- Mismo contenido: `201`, mismo cuerpo y `Location`, más `Idempotency-Replayed: true`.
- Distinto contenido: `422` con código `CLAVE_IDEMPOTENCIA_REUTILIZADA`.
- Clave con formato inválido: `400` con código `CLAVE_IDEMPOTENCIA_INVALIDA`.
- Si la creación falla (por ejemplo, matrícula duplicada), la transacción se revierte y la clave no se consume.

**Por qué no una variable en memoria.** Un mapa singleton no sirve entre réplicas ni sobrevive a un reinicio,
y no sincroniza la reserva con el efecto. Aquí la base de datos es la única fuente de verdad.

## Límites

- No hay expiración de claves; una limpieza periódica sería una extensión.
- Requiere el perfil `jpa` (PostgreSQL). El repositorio en memoria no participa de la transacción.
- La garantía se prueba con PostgreSQL real (`IdempotenciaIntegrationTest`), no con simulaciones.

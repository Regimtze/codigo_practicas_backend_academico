package mx.edu.backendacademico.controller;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import mx.edu.backendacademico.domain.Alumno;
import mx.edu.backendacademico.domain.EstatusAlumno;
import mx.edu.backendacademico.exception.IdempotenciaException;
import mx.edu.backendacademico.service.AlumnoService;
import mx.edu.backendacademico.service.CreacionIdempotenteService;
import mx.edu.backendacademico.service.CreacionIdempotenteService.Resultado;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

// Contrato HTTP de la clave de idempotencia; la garantía real se prueba con PostgreSQL.
@WebMvcTest(AlumnoController.class)
@AutoConfigureMockMvc(addFilters = false)
class IdempotenciaControllerTest {
    private static final String DATOS = "{\"matricula\":\"I1\",\"nombre\":\"Ada\",\"correo\":\"ada@u.mx\"}";
    private static final Alumno ADA = new Alumno(7L, "I1", "Ada", "ada@u.mx", EstatusAlumno.ACTIVO);

    @Autowired MockMvc mvc;
    @MockitoBean AlumnoService service;
    @MockitoBean CreacionIdempotenteService idempotente;

    @Test void laPrimeraSolicitudResponde201SinMarcaDeRepeticion() throws Exception {
        when(idempotente.crear("docente", "k1", "I1", "Ada", "ada@u.mx")).thenReturn(new Resultado(ADA, false));
        mvc.perform(post("/api/v1/alumnos").principal(() -> "docente").header("Idempotency-Key", "k1")
                .contentType(MediaType.APPLICATION_JSON).content(DATOS))
            .andExpect(status().isCreated())
            .andExpect(header().string("Location", "/api/v1/alumnos/7"))
            .andExpect(header().doesNotExist("Idempotency-Replayed"));
    }

    @Test void unaRepeticionReproduceElMismo201ConMarca() throws Exception {
        when(idempotente.crear("docente", "k1", "I1", "Ada", "ada@u.mx")).thenReturn(new Resultado(ADA, true));
        mvc.perform(post("/api/v1/alumnos").principal(() -> "docente").header("Idempotency-Key", "k1")
                .contentType(MediaType.APPLICATION_JSON).content(DATOS))
            .andExpect(status().isCreated())
            .andExpect(header().string("Location", "/api/v1/alumnos/7"))
            .andExpect(header().string("Idempotency-Replayed", "true"))
            .andExpect(jsonPath("$.id").value(7));
    }

    @Test void unaClaveConOtroContenidoResponde422() throws Exception {
        when(idempotente.crear(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenThrow(new IdempotenciaException(HttpStatus.valueOf(422), "CLAVE_IDEMPOTENCIA_REUTILIZADA", "contenido distinto"));
        mvc.perform(post("/api/v1/alumnos").principal(() -> "docente").header("Idempotency-Key", "k1")
                .contentType(MediaType.APPLICATION_JSON).content(DATOS))
            .andExpect(status().is(422))
            .andExpect(jsonPath("$.codigo").value("CLAVE_IDEMPOTENCIA_REUTILIZADA"));
    }

    @Test void unaClaveInvalidaResponde400() throws Exception {
        when(idempotente.crear(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenThrow(new IdempotenciaException(HttpStatus.BAD_REQUEST, "CLAVE_IDEMPOTENCIA_INVALIDA", "clave inválida"));
        mvc.perform(post("/api/v1/alumnos").principal(() -> "docente").header("Idempotency-Key", "no valida!")
                .contentType(MediaType.APPLICATION_JSON).content(DATOS))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.codigo").value("CLAVE_IDEMPOTENCIA_INVALIDA"));
    }

    @Test void sinCabeceraConservaElComportamientoAnterior() throws Exception {
        when(service.crear("I1", "Ada", "ada@u.mx")).thenReturn(ADA);
        mvc.perform(post("/api/v1/alumnos").contentType(MediaType.APPLICATION_JSON).content(DATOS))
            .andExpect(status().isCreated());
        verifyNoInteractions(idempotente);
    }
}

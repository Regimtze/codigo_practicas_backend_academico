package mx.edu.backendacademico.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import mx.edu.backendacademico.exception.IdempotenciaException;
import mx.edu.backendacademico.repository.jpa.AlumnoSpringDataRepository;
import mx.edu.backendacademico.service.CreacionIdempotenteService;
import mx.edu.backendacademico.service.CreacionIdempotenteService.Resultado;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.postgresql.PostgreSQLContainer;

// Usa PostgreSQL real: la garantía depende de la restricción única y de las transacciones de la base.
@SpringBootTest
@Testcontainers
class IdempotenciaIntegrationTest {
    @Container
    static PostgreSQLContainer postgres = new PostgreSQLContainer("postgres:17-alpine");

    @DynamicPropertySource
    static void properties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired CreacionIdempotenteService servicio;
    @Autowired AlumnoSpringDataRepository alumnos;

    private long contar(String matricula) {
        return alumnos.findAll().stream().filter(a -> a.toDomain().matricula().equals(matricula)).count();
    }

    @Test void dosSolicitudesSimultaneasConLaMismaClaveCreanUnSoloAlumno() throws Exception {
        var salida = new CountDownLatch(1);
        try (var pool = Executors.newFixedThreadPool(2)) {
            Callable<Resultado> solicitud = () -> {
                salida.await();
                return servicio.crear("docente", "clave-simultanea", "IDEM1", "Ada Lovelace", "ada@u.mx");
            };
            var a = pool.submit(solicitud);
            var b = pool.submit(solicitud);
            salida.countDown();
            var ra = a.get(30, TimeUnit.SECONDS);
            var rb = b.get(30, TimeUnit.SECONDS);

            // Ambas obtienen el mismo alumno; exactamente una ejecutó la creación.
            assertEquals(ra.alumno().id(), rb.alumno().id());
            assertEquals(1, Stream.of(ra, rb).filter(r -> !r.repetida()).count());
            assertEquals(1, contar("IDEM1"));
        }
    }

    @Test void laMismaClaveConOtroContenidoSeRechazaYNoCreaNada() {
        var primera = servicio.crear("docente", "clave-distinta", "IDEM2", "Ada Lovelace", "ada@u.mx");
        assertFalse(primera.repetida());

        var ex = assertThrows(IdempotenciaException.class, () ->
            servicio.crear("docente", "clave-distinta", "IDEM3", "Emmy Noether", "emmy@u.mx"));
        assertEquals("CLAVE_IDEMPOTENCIA_REUTILIZADA", ex.getCodigo());
        assertEquals(422, ex.getStatus().value());
        assertEquals(1, contar("IDEM2"));
        assertEquals(0, contar("IDEM3"));
    }

    @Test void unaRepeticionSecuencialReproduceElMismoAlumno() {
        var primera = servicio.crear("docente", "clave-secuencial", "IDEM4", "Ada Lovelace", "ada@u.mx");
        var repetida = servicio.crear("docente", "clave-secuencial", "IDEM4", "Ada Lovelace", "ada@u.mx");
        assertFalse(primera.repetida());
        assertTrue(repetida.repetida());
        assertEquals(primera.alumno().id(), repetida.alumno().id());
        assertEquals(1, contar("IDEM4"));
    }

    @Test void laClaveSoloPerteneceAlSolicitanteQueLaUso() {
        var uno = servicio.crear("docente", "clave-compartida", "IDEM5", "Ada Lovelace", "ada@u.mx");
        var otro = servicio.crear("admin", "clave-compartida", "IDEM6", "Emmy Noether", "emmy@u.mx");
        assertFalse(uno.repetida());
        assertFalse(otro.repetida());
        assertNotEquals(uno.alumno().id(), otro.alumno().id());
    }
}

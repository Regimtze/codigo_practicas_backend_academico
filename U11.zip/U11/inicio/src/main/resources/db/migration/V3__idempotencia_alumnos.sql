-- Reserva de claves de idempotencia para la creación de alumnos.
-- La clave pertenece al solicitante: dos usuarios pueden usar el mismo texto sin colisionar.
CREATE TABLE idempotencia_alumnos (
    principal VARCHAR(100) NOT NULL,
    clave VARCHAR(80) NOT NULL,
    -- SHA-256 en hexadecimal del contenido canónico de la solicitud.
    huella CHAR(64) NOT NULL,
    -- Se asigna en la misma transacción que crea el alumno.
    alumno_id BIGINT,
    creada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_idempotencia_alumnos PRIMARY KEY (principal, clave),
    CONSTRAINT fk_idempotencia_alumno FOREIGN KEY (alumno_id) REFERENCES alumnos(id) ON DELETE CASCADE
);

package mx.edu.backendacademico.service;

// Crea alumnos una sola vez por (solicitante, clave). La reserva de la clave y el alumno
// se confirman en la misma transacción; no se usa memoria compartida del proceso.

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Locale;
import java.util.regex.Pattern;
import javax.sql.DataSource;
import mx.edu.backendacademico.domain.Alumno;
import mx.edu.backendacademico.exception.IdempotenciaException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CreacionIdempotenteService {
    private static final Pattern CLAVE_VALIDA = Pattern.compile("[A-Za-z0-9._-]{1,80}");

    private final AlumnoService alumnos;
    private final JdbcClient jdbc;

    public CreacionIdempotenteService(AlumnoService alumnos, DataSource dataSource) {
        this.alumnos = alumnos;
        // JpaTransactionManager comparte la conexión con JDBC: ambos operan en la misma transacción.
        this.jdbc = JdbcClient.create(dataSource);
    }

    public record Resultado(Alumno alumno, boolean repetida) { }

    @Transactional
    public Resultado crear(String principal, String clave, String matricula, String nombre, String correo) {
        if (clave == null || !CLAVE_VALIDA.matcher(clave).matches()) {
            throw new IdempotenciaException(HttpStatus.BAD_REQUEST, "CLAVE_IDEMPOTENCIA_INVALIDA",
                "La clave debe tener de 1 a 80 caracteres: letras, dígitos, punto, guion o guion bajo");
        }
        var huella = huella(matricula, nombre, correo);

        // 1. Reserva atómica. Si otra transacción reservó la misma clave sin confirmar,
        //    esta sentencia espera su commit o rollback antes de decidir.
        int reservada = jdbc.sql("""
                INSERT INTO idempotencia_alumnos (principal, clave, huella)
                VALUES (:principal, :clave, :huella)
                ON CONFLICT (principal, clave) DO NOTHING
                """)
            .param("principal", principal).param("clave", clave).param("huella", huella)
            .update();

        if (reservada == 1) {
            // 2. Primera solicitud: el efecto y la confirmación de la clave viajan juntos.
            var creado = alumnos.crear(matricula, nombre, correo);
            jdbc.sql("UPDATE idempotencia_alumnos SET alumno_id = :id WHERE principal = :principal AND clave = :clave")
                .param("id", creado.id()).param("principal", principal).param("clave", clave)
                .update();
            return new Resultado(creado, false);
        }

        // 3. Repetición: la reserva ya está confirmada. Compara contenido antes de reproducir.
        var previa = jdbc.sql("SELECT huella, alumno_id FROM idempotencia_alumnos WHERE principal = :principal AND clave = :clave")
            .param("principal", principal).param("clave", clave)
            .query((rs, n) -> new Previa(rs.getString("huella").strip(), rs.getLong("alumno_id")))
            .single();
        if (!previa.huella().equals(huella)) {
            throw new IdempotenciaException(HttpStatus.valueOf(422), "CLAVE_IDEMPOTENCIA_REUTILIZADA",
                "La clave ya se usó con un contenido distinto");
        }
        return new Resultado(alumnos.buscar(previa.alumnoId()), true);
    }

    private record Previa(String huella, long alumnoId) { }

    // Huella del contenido canónico; los campos llevan longitud para evitar ambigüedad entre ellos.
    static String huella(String matricula, String nombre, String correo) {
        var canonico = campo(matricula.strip().toUpperCase(Locale.ROOT)) + campo(nombre.strip()) + campo(correo.strip());
        try {
            var resumen = MessageDigest.getInstance("SHA-256").digest(canonico.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(resumen);
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("SHA-256 no disponible", ex);
        }
    }

    private static String campo(String valor) { return valor.length() + ":" + valor + ";"; }
}

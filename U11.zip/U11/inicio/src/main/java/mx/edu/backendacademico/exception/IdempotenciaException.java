package mx.edu.backendacademico.exception;

// Representa un uso incorrecto de la clave de idempotencia.

import org.springframework.http.HttpStatus;

public class IdempotenciaException extends RuntimeException {
    private final HttpStatus status;
    private final String codigo;

    public IdempotenciaException(HttpStatus status, String codigo, String mensaje) {
        super(mensaje);
        this.status = status;
        this.codigo = codigo;
    }

    public HttpStatus getStatus() { return status; }
    public String getCodigo() { return codigo; }
}
